let result = 0;
let n1 = 21;
let n2 = 2;

const multiple = (x, y) => {
    result = n1*n2;
    return console.log(`${n1} X ${n2} = ${result}`);
}

multiple(n1, n2);