const getSoma = async (x, y) => {
    const response = await x + y;
    console.log(response);
}

getSoma(1, 1);