const date = new Date();

const { format } = require('date-fns');

console.log(format(date, 'dd/MM/yyyy'));
